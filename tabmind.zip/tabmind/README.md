# 🧠 TabMind

> AI tab organizer that works with **any AI provider**. One click — chaos becomes order.

![TabMind v2](screenshot.png)

## Supported Providers

| Provider | Adapter | Notes |
|----------|---------|-------|
| Claude (Anthropic) | Native | claude-opus-4-5, claude-haiku... |
| ChatGPT (OpenAI) | OpenAI | gpt-4o, gpt-4o-mini... |
| DeepSeek | OpenAI-compat | deepseek-chat, deepseek-reasoner |
| Groq | OpenAI-compat | llama-3.3-70b, mixtral... |
| Gemini (Google) | Native | gemini-2.0-flash, gemini-1.5-pro |
| Mistral | OpenAI-compat | mistral-small, codestral... |
| OpenRouter | OpenAI-compat | Any model via single API |
| Grok (xAI) | OpenAI-compat | grok-3-mini, grok-3 |
| Qwen (Alibaba) | OpenAI-compat | qwen-turbo, qwen-max |
| Kimi (Moonshot) | OpenAI-compat | moonshot-v1-8k |
| Together AI | OpenAI-compat | Llama, Mistral, many more |
| Perplexity | OpenAI-compat | sonar models |
| **Custom URL** | OpenAI-compat | Any OpenAI-compatible API |

## Features

- **Multi-provider** — switch providers in one click, keys saved per provider
- **Auto-group** — triggers automatically when tab count exceeds your threshold
- **Smart filtering** — system tabs (chrome://, about:) go to "Другое" group  
- **Custom URL** — connect any local or custom OpenAI-compatible endpoint (Ollama, LM Studio, etc.)
- **Model override** — change the model without touching code
- **Key persistence** — each provider remembers its own API key

## Install

1. Download ZIP and extract
2. Open `chrome://extensions` → enable **Developer mode**
3. Click **Load unpacked** → select the `tabmind` folder
4. Click the extension icon, pick your provider, paste API key → **Group my tabs**

## Local models (Ollama, LM Studio)

Select **Custom URL** and enter:
- Ollama: `http://localhost:11434/v1` (no API key needed, enter any string)
- LM Studio: `http://localhost:1234/v1`

## Stack

- Chrome Extension Manifest V3
- Vanilla JS — zero dependencies, no build step
- Chrome Tab Groups API
- Supports: OpenAI, Anthropic, Gemini adapters

## License

MIT — do whatever you want with it.
